import { registerRootComponent } from "expo";
import App from "./Main/index";

registerRootComponent(App);
