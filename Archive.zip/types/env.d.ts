declare module "@env" {
  export const BACKEND_URL: string;
  export const APP_ENV: string;
}
